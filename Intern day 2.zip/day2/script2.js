// function toggleChange(){
//     document.body.classList.toggle('darkmode')
//     document.body.classList.toggle('lightMode')

// }
// function showDate(){
//     document.getElementById('dateAndTime').innerText=data()
// }

// document.querySelector('p ul li a').computedStyleMap.backgroundColor = 'blue'

// document.querySelector('#first').innerHTML='Lorem ipsum dolor sit amet consectetur adipisicing elit. Harum dicta saepe magni quam aperiam nobis temporibus fugiat! Atque a et quas dolores ipsam hic nesciunt soluta? Exercitationem soluta accusamus quos'
// document.querySelector('#first').style.color = 'red'

// let items=document.querySelectorAll('.items')
// items.forEach(item=>{
//     items.style.color='white';
//     items.style.backgroundColor='blue'
// })